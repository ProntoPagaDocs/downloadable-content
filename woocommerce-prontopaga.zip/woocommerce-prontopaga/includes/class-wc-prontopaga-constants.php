<?php
if (!defined('ABSPATH')) {
  exit;
}

class WC_PRONTOPAGA_CONSTANTS
{
  const PP_PLUGIN_ID = 'prontopaga';
  const PP_PLUGIN_TITLE = 'ProntoPaga';
  const PP_PLUGIN_DESCRIPTION = 'Acepta pagos con tarjeta, billeteras electrónicas y Yape.';

  /** Sandbox API base URL. */
  const PP_BASE_URL_SANDBOX = 'https://sandbox.prontopaga.com/';

  /** Production API base URL. */
  const PP_BASE_URL_PROD = 'https://prontopaga.com/';

  const PP_PAYMENT_METHODS = 'api/payment/methods';
  const PP_PAYMENT_NEW = 'api/payment/new';
  const PP_PAYMENT_DATA = 'api/payment/data/';
}
