<?php
return array(
  'enabled' => array(
    'title' => 'Activado/Desactivado',
    'type' => 'checkbox',
    'label' => 'Activar Módulo.',
    'default' => 'no'
  ),
  'saveLog' => array(
    'title' => 'Log',
    'type' => 'checkbox',
    'label' => 'Activar registro de log.',
    'default' => 'no'
  )
);
