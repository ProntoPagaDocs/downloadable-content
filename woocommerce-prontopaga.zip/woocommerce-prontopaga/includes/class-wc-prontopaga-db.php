<?php
if (!defined('ABSPATH')) {
  exit;
}

class WC_PRONTOPAGA_DB
{
  public static function prontoPagaCreateTableConfig()
  {
    global $wpdb;
    $tableName = $wpdb->prefix . 'pp_config';
    $charsetCollate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS $tableName (
      id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
      name VARCHAR(500) NOT NULL DEFAULT '',
      value LONGTEXT NOT NULL,
      created_at DATETIME NOT NULL,
      updated_at DATETIME NOT NULL
    ) $charsetCollate;";
    $wpdb->query($sql);

    // Older installs used VARCHAR(5000); widen so multiple logos can be stored.
    $wpdb->query("ALTER TABLE {$tableName} MODIFY value LONGTEXT NOT NULL");
  }

  public static function prontoPagaCreateTableOrder()
  {
    global $wpdb;
    $tableName = $wpdb->prefix . 'pp_order';
    $charsetCollate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS $tableName (
      id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
      order_id INT NOT NULL,
      order_code VARCHAR(50) NOT NULL DEFAULT '',
      order_status VARCHAR(50) NOT NULL DEFAULT 'pending',
      uuid VARCHAR(250) NOT NULL DEFAULT '',
      payment_method VARCHAR(250) NOT NULL DEFAULT '',
      api_request TEXT NOT NULL DEFAULT '',
      check_request TINYINT(1) NOT NULL DEFAULT '0',
      api_response TEXT NOT NULL DEFAULT '',
      created_at DATETIME NOT NULL,
      updated_at DATETIME NOT NULL
    ) $charsetCollate;";
    $wpdb->query($sql);
  }

  public static function prontoPagaGetConfig()
  {
    global $wpdb;
    $tableName = $wpdb->prefix . 'pp_config';
    $results = $wpdb->get_results("SELECT * FROM $tableName");
    if (count($results) == 0) return null;
    return $results;
  }

  public static function prontoPagaInsertDataTableConfig()
  {
    global $wpdb;
    $date = date("Y-m-d H:i:s");
    $tableName = $wpdb->prefix . 'pp_config';
    $rows = $wpdb->get_var('SELECT COUNT(*) FROM ' . $tableName);
    if ($rows == 0) {
      $wpdb->insert($tableName, array('name' => "API_TOKEN", 'value' => "", 'created_at' => $date, 'updated_at' => $date));
      $wpdb->insert($tableName, array('name' => "API_KEY", 'value' => "", 'created_at' => $date, 'updated_at' => $date));
      $wpdb->insert($tableName, array('name' => "TITLE", 'value' => "", 'created_at' => $date, 'updated_at' => $date));
      $wpdb->insert($tableName, array('name' => "DESCRIPTION", 'value' => "", 'created_at' => $date, 'updated_at' => $date));
      $wpdb->insert($tableName, array('name' => "ENVIRONMENT", 'value' => "S", 'created_at' => $date, 'updated_at' => $date));
      $wpdb->insert($tableName, array('name' => "STATUS", 'value' => "processing", 'created_at' => $date, 'updated_at' => $date));
      $wpdb->insert($tableName, array('name' => "PAYMENT_METHODS", 'value' => "", 'created_at' => $date, 'updated_at' => $date));
      $wpdb->insert($tableName, array('name' => "CHECKOUT_LOGO", 'value' => "", 'created_at' => $date, 'updated_at' => $date));
    } else {
      // Ensure newer config keys exist on updated installs.
      $has_logo = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$tableName} WHERE name = %s", 'CHECKOUT_LOGO'));
      if ((int) $has_logo === 0) {
        $wpdb->insert($tableName, array('name' => 'CHECKOUT_LOGO', 'value' => '', 'created_at' => $date, 'updated_at' => $date));
      }
    }
  }

  public static function prontoPagaUpdateConfig($name, $value)
  {
    global $wpdb;
    $tableName = $wpdb->prefix . 'pp_config';
    $exists    = $wpdb->get_var(
      $wpdb->prepare("SELECT COUNT(*) FROM {$tableName} WHERE name = %s", $name)
    );

    if ((int) $exists > 0) {
      $wpdb->update(
        $tableName,
        array(
          'value'      => $value,
          'updated_at' => current_time('mysql'),
        ),
        array('name' => $name)
      );
      return;
    }

    $now = current_time('mysql');
    $wpdb->insert(
      $tableName,
      array(
        'name'       => $name,
        'value'      => $value,
        'created_at' => $now,
        'updated_at' => $now,
      )
    );
  }

  /**
   * Get a single config value by name.
   *
   * @param string      $name Config key.
   * @param string|null $default Default value. Pass null to detect missing keys.
   * @return string|null
   */
  public static function prontoPagaGetConfigValue($name, $default = '')
  {
    global $wpdb;
    $tableName = $wpdb->prefix . 'pp_config';
    $row       = $wpdb->get_row(
      $wpdb->prepare("SELECT value FROM {$tableName} WHERE name = %s LIMIT 1", $name)
    );
    if ($row === null) {
      return $default;
    }
    return (string) $row->value;
  }

  public static function prontoPagaInsertDataTableOrder($order_id, $order_code, $uuid, $api_request, $status, $paymentMethod)
  {
    global $wpdb;
    $date = date("Y-m-d H:i:s");
    $wpdb->insert(
      $wpdb->prefix . 'pp_order',
      array(
        'order_id' => $order_id,
        'order_code' => $order_code,
        'order_status' => $status,
        'uuid' => $uuid,
        'payment_method' => $paymentMethod,
        'api_request' => $api_request,
        'created_at' => $date,
        'updated_at' => $date
      )
    );
  }

  public static function prontoPagaUpdateOrder($id, $status)
  {
    global $wpdb;
    $tableName = $wpdb->prefix . 'pp_order';
    $wpdb->update($tableName, array('order_status' => $status, 'updated_at' => date("Y-m-d H:i:s")), array('id' => $id));
  }

  public static function prontoPagaGetOrderByOrderCode($orderCode)
  {
    global $wpdb;
    $tableName = $wpdb->prefix . 'pp_order';
    $results   = $wpdb->get_results(
      $wpdb->prepare("SELECT * FROM {$tableName} WHERE order_code = %s LIMIT 1", $orderCode)
    );
    if (empty($results)) {
      return null;
    }
    return $results[0];
  }

  public static function prontoPagaGetOrderByUid($uid)
  {
    global $wpdb;
    $tableName = $wpdb->prefix . 'pp_order';
    $results   = $wpdb->get_results(
      $wpdb->prepare("SELECT * FROM {$tableName} WHERE uuid = %s LIMIT 1", $uid)
    );
    if (empty($results)) {
      return null;
    }
    return $results[0];
  }
}
