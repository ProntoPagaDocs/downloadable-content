<?php
if (!defined('ABSPATH')) {
  exit;
}

class WC_PRONTOPAGA_UTILS
{
  public static function saveInfoLog($title, $message)
  {
    $logger = wc_get_logger();
    $context = array('source' => 'prontopaga');
    $logger->info($title . ': ' . $message, $context);
  }

  public static function saveErrorLog($title, $message)
  {
    $logger = wc_get_logger();
    $context = array('source' => 'prontopaga');
    $logger->error($title . ': ' . $message, $context);
  }

  public static function getPaymentBodyPP($order, $apiKey, $amount, $paymentMethod, $orderCode, $pluginUrl, $clientDocument)
  {
    $data = [
      'currency' => get_woocommerce_currency(),
      'country' => $order->get_billing_country(),
      'amount' => $amount,
      'paymentMethod' => $paymentMethod,
      'urlFinal' => $pluginUrl . '/api/process_payment.php?code=' . $orderCode,
      'urlConfirmation' => $pluginUrl . '/api/webhook.php',
      'order' => $orderCode,
      'clientName' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
      'clientEmail' => $order->get_billing_email(),
      'clientPhone' => $order->get_billing_phone(),
      'clientDocument' => $clientDocument,
    ];

    $keys = array_keys($data);
    sort($keys);
    $toSign = '';

    foreach ($keys as $key) {
      $toSign .= $key . $data[$key];
    }

    $sign = hash_hmac('sha256', $toSign, $apiKey);
    $data['sign'] = $sign;

    return $data;
  }

  /**
   * Raw PAYMENT_METHODS config value from DB.
   *
   * @return string
   */
  public static function getPaymentMethodsRaw()
  {
    $configs = WC_PRONTOPAGA_DB::prontoPagaGetConfig();
    if (!$configs) {
      return '';
    }
    foreach ($configs as $c) {
      if ($c->name === 'PAYMENT_METHODS') {
        return (string) $c->value;
      }
    }
    return '';
  }

  /**
   * Normalize stored payment methods into a map keyed by method id.
   * Supports legacy format (array of ids) and new format (objects with logo/name).
   *
   * @param string|array $raw Config value.
   * @return array<string, array{id:string,method:string,name:string,logo:string,enabled:bool}>
   */
  public static function normalizePaymentMethodsConfig($raw)
  {
    if (is_string($raw)) {
      $decoded = json_decode($raw, true);
    } else {
      $decoded = $raw;
    }

    if (!is_array($decoded)) {
      return array();
    }

    $normalized = array();

    // Legacy: [1, 2, 3]
    $is_legacy_ids = array_keys($decoded) === range(0, count($decoded) - 1)
      && (empty($decoded) || !is_array(reset($decoded)));

    if ($is_legacy_ids) {
      foreach ($decoded as $id) {
        $id_key = (string) $id;
        $normalized[$id_key] = array(
          'id'      => $id_key,
          'method'  => '',
          'name'    => '',
          'logo'    => '',
          'enabled' => true,
        );
      }
      return $normalized;
    }

    foreach ($decoded as $key => $item) {
      if (!is_array($item)) {
        continue;
      }

      $id = isset($item['id']) ? (string) $item['id'] : (string) $key;
      if ($id === '') {
        continue;
      }

      $enabled = true;
      if (array_key_exists('enabled', $item)) {
        $enabled = !empty($item['enabled']) && $item['enabled'] !== '0' && $item['enabled'] !== false;
      }

      $normalized[$id] = array(
        'id'      => $id,
        'method'  => isset($item['method']) ? (string) $item['method'] : '',
        'name'    => isset($item['name']) ? (string) $item['name'] : '',
        'logo'    => isset($item['logo']) ? (string) $item['logo'] : '',
        'enabled' => $enabled,
      );
    }

    return $normalized;
  }

  /**
   * Enabled payment methods for checkout (local logos only).
   *
   * @return array<int, array{id:string,method:string,name:string,logo:string}>
   */
  public static function getEnabledPaymentMethods()
  {
    $methods = self::normalizePaymentMethodsConfig(self::getPaymentMethodsRaw());
    $enabled = array();

    foreach ($methods as $method) {
      if (empty($method['enabled'])) {
        continue;
      }
      if ($method['method'] === '') {
        continue;
      }
      $enabled[] = array(
        'id'     => $method['id'],
        'method' => $method['method'],
        'name'   => $method['name'] !== '' ? $method['name'] : $method['method'],
        'logo'   => $method['logo'],
      );
    }

    return $enabled;
  }

  /**
   * Build config payload from admin POST.
   *
   * @param array $posted $_POST['ppPaymentMethods'] style data.
   * @return array
   */
  public static function buildPaymentMethodsFromPost($posted)
  {
    if (!is_array($posted)) {
      return array();
    }

    $saved = array();

    foreach ($posted as $id => $row) {
      if (!is_array($row)) {
        continue;
      }

      $id_key  = isset($row['id']) ? sanitize_text_field(wp_unslash($row['id'])) : sanitize_text_field((string) $id);
      $enabled = !empty($row['enabled']);

      if (!$enabled) {
        continue;
      }

      $method = isset($row['method']) ? sanitize_text_field(wp_unslash($row['method'])) : '';
      $name   = isset($row['name']) ? sanitize_text_field(wp_unslash($row['name'])) : '';
      $logo   = isset($row['logo']) ? esc_url_raw(wp_unslash($row['logo'])) : '';

      if ($method === '') {
        continue;
      }

      $saved[] = array(
        'id'      => $id_key,
        'method'  => $method,
        'name'    => $name !== '' ? $name : $method,
        'logo'    => $logo,
        'enabled' => true,
      );
    }

    return $saved;
  }

  /**
   * Known billing document field keys used by themes/plugins.
   *
   * @return string[]
   */
  public static function getDocumentFieldCandidates()
  {
    return array(
      'billing_prontopaga_dni',
      'billing_dni',
      'billing_document',
      'billing_documento',
      'billing_cedula',
      'billing_ci',
      'billing_rut',
      'billing_cpf',
      'billing_rfc',
      'billing_nit',
    );
  }

  /**
   * Whether checkout billing fields already include a document field.
   *
   * @param array $fields Billing fields.
   * @return bool
   */
  public static function billingHasDocumentField($fields)
  {
    if (!is_array($fields)) {
      return false;
    }
    foreach (self::getDocumentFieldCandidates() as $key) {
      if (isset($fields[$key])) {
        return true;
      }
    }
    return false;
  }

  /**
   * Resolve customer document from request / order / Blocks additional fields.
   *
   * @param WC_Order|null $order Order object when available.
   * @return string
   */
  public static function getCustomerDocument($order = null)
  {
    $candidates = array();

    $push = function ($value) use (&$candidates) {
      if (!is_scalar($value)) {
        return;
      }
      $value = sanitize_text_field(wp_unslash((string) $value));
      if ($value !== '') {
        $candidates[] = $value;
      }
    };

    // Direct POST / REQUEST keys.
    $post_keys = array_merge(
      array(
        'prontoPaga_input_dni',
        'billing_prontopaga_dni',
        'prontopaga/dni',
        'clientDocument',
      ),
      self::getDocumentFieldCandidates()
    );
    foreach ($post_keys as $key) {
      if (isset($_POST[$key])) {
        $push($_POST[$key]);
      } elseif (isset($_REQUEST[$key])) {
        $push($_REQUEST[$key]);
      }
    }

    // Blocks payment_data array: [ ['key' => '...', 'value' => '...'], ... ]
    if (isset($_POST['payment_data']) && is_array($_POST['payment_data'])) {
      foreach ($_POST['payment_data'] as $entry) {
        if (!is_array($entry) || empty($entry['key'])) {
          continue;
        }
        $key = (string) $entry['key'];
        if (
          $key === 'prontoPaga_input_dni'
          || $key === 'billing_prontopaga_dni'
          || $key === 'prontopaga/dni'
          || $key === 'clientDocument'
          || in_array($key, self::getDocumentFieldCandidates(), true)
        ) {
          $push(isset($entry['value']) ? $entry['value'] : '');
        }
      }
    }

    if (isset($_POST['additional_fields']) && is_array($_POST['additional_fields'])) {
      foreach (array('prontopaga/dni', 'billing_prontopaga_dni') as $key) {
        if (!empty($_POST['additional_fields'][$key])) {
          $push($_POST['additional_fields'][$key]);
        }
      }
    }

    // Nested billing arrays.
    if (isset($_POST['billing']) && is_array($_POST['billing'])) {
      foreach (array('prontopaga_dni', 'dni', 'document', 'documento') as $key) {
        if (!empty($_POST['billing'][$key])) {
          $push($_POST['billing'][$key]);
        }
      }
    }

    if (!empty($candidates)) {
      return $candidates[0];
    }

    if ($order && is_a($order, 'WC_Order')) {
      $meta_keys = array(
        '_billing_prontopaga_dni',
        'billing_prontopaga_dni',
        '_wc_billing/prontopaga/dni',
        '_wc_shipping/prontopaga/dni',
        '_wc_other/prontopaga/dni',
        'prontopaga/dni',
        '_prontopaga/dni',
        '_billing_dni',
        'billing_dni',
        '_billing_document',
        'billing_document',
        '_billing_documento',
        'billing_documento',
        '_billing_cedula',
        'billing_cedula',
      );
      foreach ($meta_keys as $meta_key) {
        $value = $order->get_meta($meta_key, true);
        if (is_string($value) && trim($value) !== '') {
          return sanitize_text_field($value);
        }
      }

      if (class_exists('\Automattic\WooCommerce\Blocks\Package')) {
        try {
          $checkout_fields = \Automattic\WooCommerce\Blocks\Package::container()->get(
            \Automattic\WooCommerce\Blocks\Domain\Services\CheckoutFields::class
          );
          foreach (array('billing', 'shipping', 'other') as $group) {
            $value = $checkout_fields->get_field_from_object('prontopaga/dni', $order, $group);
            if (is_string($value) && trim($value) !== '') {
              return sanitize_text_field($value);
            }
          }
        } catch (Throwable $e) {
          // Ignore Blocks field lookup errors.
        }
      }
    }

    return '';
  }
}
