<?php
if (!defined('ABSPATH')) {
  exit;
}

include_once dirname(__FILE__) . '/class-wc-prontopaga-constants.php';
include_once dirname(__FILE__) . '/class-wc-prontopaga-utils.php';

class WC_PRONTOPAGA_API
{

  public static function getEnvironmentPP($env)
  {
    $env = strtoupper(trim((string) $env));

    if ($env === 'P' || $env === 'PROD' || $env === 'PRODUCTION') {
      return WC_PRONTOPAGA_CONSTANTS::PP_BASE_URL_PROD;
    }

    // Default / Sandbox: S, sandbox, empty, etc.
    return WC_PRONTOPAGA_CONSTANTS::PP_BASE_URL_SANDBOX;
  }

  public static function getPaymentMethods($environment, $token)
  {
    $headers = array('Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json');
    $response = wp_remote_get(
      WC_PRONTOPAGA_API::getEnvironmentPP($environment) . WC_PRONTOPAGA_CONSTANTS::PP_PAYMENT_METHODS . '/' . get_woocommerce_currency(),
      ['headers' => $headers]
    );
    if (is_wp_error($response)) return null;
    return $response;
    // if (wp_remote_retrieve_response_code($response) !== 200) return null;
    // return wp_remote_retrieve_body($response);

    // $ch = curl_init(WC_PRONTOPAGA_API::getEnvironmentPP($environment) . WC_PRONTOPAGA_CONSTANTS::PP_PAYMENT_METHODS . '/' . get_woocommerce_currency());
    // curl_setopt_array($ch, [
    //   CURLOPT_RETURNTRANSFER => true,
    //   CURLOPT_HTTPHEADER => ["Authorization: Bearer " . $token]
    // ]);
    // $response = curl_exec($ch);
    // $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    // if ($httpCode !== 200) {
    //   return null;
    // }
    // return $response;
  }

  public static function newPaymentPP($environment, $token, $body)
  {
    $headers = array('Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json');
    $response = wp_remote_post(
      WC_PRONTOPAGA_API::getEnvironmentPP($environment) . WC_PRONTOPAGA_CONSTANTS::PP_PAYMENT_NEW,
      ['headers' => $headers, 'body' => wp_json_encode($body)]
    );
    if (is_wp_error($response)) {
      WC_PRONTOPAGA_UTILS::saveErrorLog("Error-newPayment", wp_remote_retrieve_body($response));
      return null;
    };
    WC_PRONTOPAGA_UTILS::saveErrorLog("newPayment: ", wp_remote_retrieve_body($response));
    return $response;
  }

  public static function getPaymentStatusPP($environment, $token, $uid)
  {
    $headers = array('Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json');
    $response = wp_remote_get(
      WC_PRONTOPAGA_API::getEnvironmentPP($environment) . WC_PRONTOPAGA_CONSTANTS::PP_PAYMENT_DATA . $uid,
      ['headers' => $headers]
    );
    if (is_wp_error($response)) return null;
    return $response;
    // if (wp_remote_retrieve_response_code($response) !== 200) return null;
    // return wp_remote_retrieve_body($response);
  }

  // public static function generateTokenPW($env, $user, $pwd, $save)
  // {
  //   $baseUrl = self::getEnvironment($env);
  //   $url = $baseUrl . WC_NIUBIZ_CONSTANTS::NBZ_ENPOINT_SECURITY;
  //   $curl = curl_init();
  //   curl_setopt_array($curl, array(
  //     CURLOPT_URL => $url,
  //     CURLOPT_RETURNTRANSFER => true,
  //     CURLOPT_ENCODING => "",
  //     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  //     CURLOPT_CUSTOMREQUEST => "POST",
  //     CURLOPT_HTTPHEADER => array(
  //       "Accept: */*",
  //       'Authorization: ' . 'Basic ' . base64_encode($user . ":" . $pwd)
  //     ),
  //   ));
  //   $token = curl_exec($curl);
  //   curl_close($curl);
  //   if ($save == '1') {
  //     WC_NIUBIZ_UTILS::saveLog('URL', $url);
  //     WC_NIUBIZ_UTILS::saveLog('Token', $token);
  //   }
  //   return $token;
  // }

  // public static function postRequest($url, $postData, $token, $save)
  // {
  //   $curl = curl_init();
  //   curl_setopt_array($curl, array(
  //     CURLOPT_URL => $url,
  //     CURLOPT_RETURNTRANSFER => true,
  //     CURLOPT_ENCODING => "",
  //     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  //     CURLOPT_CUSTOMREQUEST => "POST",
  //     CURLOPT_HTTPHEADER => array(
  //       'Authorization: ' . $token,
  //       'Content-Type: application/json'
  //     ),
  //     CURLOPT_POSTFIELDS => $postData
  //   ));
  //   $response = curl_exec($curl);
  //   curl_close($curl);
  //   if ($save == '1') {
  //     WC_NIUBIZ_UTILS::saveLog('URL', $url);
  //     WC_NIUBIZ_UTILS::saveLog('Request', $postData);
  //     WC_NIUBIZ_UTILS::saveLog('Response', $response);
  //   }
  //   return $response;
  // }

  // public static function generateSessionPW($env, $amount, $merchant, $mdd, $token, $recurrenceAmount, $save)
  // {
  //   $baseUrl = self::getEnvironment($env);
  //   $session = array(
  //     'amount' => $amount,
  //     'antifraud' => array(
  //       'clientIp' => $_SERVER['REMOTE_ADDR'],
  //       'merchantDefineData' => $mdd
  //     ),
  //     'channel' => 'web',
  //     'recurrenceMaxAmount' => $recurrenceAmount,
  //   );
  //   $json = json_encode($session);
  //   $url = $baseUrl . WC_NIUBIZ_CONSTANTS::NBZ_ENPOINT_SESSION . $merchant;
  //   $response = json_decode(self::postRequest($url, $json, $token, $save));
  //   return $response->sessionKey;
  // }

  // public static function generateAuthorizationPW($env, $amount, $currency, $purchaseNumber, $transactionToken, $productId, $merchant, $token, $cardHolder, $recurrence, $save)
  // {
  //   $baseUrl = self::getEnvironment($env);
  //   $data = array(
  //     'antifraud' => null,
  //     'captureType' => 'manual',
  //     'channel' => 'web',
  //     'countable' => true,
  //     'order' => array(
  //       'amount' => $amount,
  //       'currency' => $currency,
  //       'purchaseNumber' => $purchaseNumber,
  //       'tokenId' => $transactionToken,
  //       'productId' => $productId
  //     ),
  //     'cardHolder' => $cardHolder,
  //     'recurrence' => $recurrence
  //   );
  //   $json = json_encode($data);
  //   $url = $baseUrl . WC_NIUBIZ_CONSTANTS::NBZ_ENPOINT_AUTHORIZATION . $merchant;
  //   $response = json_decode(self::postRequest($url, $json, $token, $save));
  //   return $response;
  // }
}
