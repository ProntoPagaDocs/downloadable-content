<?php
/**
 * WooCommerce Blocks payment method integration for ProntoPaga.
 *
 * @package WooCommerce_ProntoPaga
 */

if (!defined('ABSPATH')) {
  exit;
}

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * ProntoPaga Blocks payment method type.
 */
final class WC_ProntoPaga_Blocks extends AbstractPaymentMethodType
{
  /**
   * Payment method name matching gateway id / JS registration name.
   *
   * @var string
   */
  protected $name = 'prontopaga';

  /**
   * Gateway instance when available.
   *
   * @var WC_ProntoPaga|null
   */
  private $gateway = null;

  /**
   * Initialize settings from the payment gateway.
   */
  public function initialize()
  {
    $this->settings = get_option('woocommerce_prontopaga_settings', array());

    if (function_exists('WC') && WC()->payment_gateways()) {
      $gateways = WC()->payment_gateways()->payment_gateways();
      if (isset($gateways['prontopaga']) && $gateways['prontopaga'] instanceof WC_Payment_Gateway) {
        $this->gateway = $gateways['prontopaga'];
      }
    }
  }

  /**
   * Whether the payment method should load on Blocks checkout.
   *
   * @return bool
   */
  public function is_active()
  {
    if ($this->gateway) {
      return $this->gateway->is_available();
    }

    return ($this->get_setting('enabled', 'no') === 'yes');
  }

  /**
   * Register and return frontend script handles.
   *
   * @return string[]
   */
  public function get_payment_method_script_handles()
  {
    $script_path = 'assets/js/blocks-checkout.js';
    $script_url  = PP_PLUGIN_URL . $script_path;
    $asset_path = PP_DIR . 'assets/js/blocks-checkout.asset.php';

    $dependencies = array(
      'wc-blocks-registry',
      'wc-settings',
      'wp-element',
      'wp-html-entities',
      'wp-i18n',
    );
    $version = PP_VERSION;

    if (file_exists($asset_path)) {
      $asset        = include $asset_path;
      $dependencies = isset($asset['dependencies']) ? $asset['dependencies'] : $dependencies;
      $version      = isset($asset['version']) ? $asset['version'] : $version;
    }

    wp_register_script(
      'wc-prontopaga-blocks',
      $script_url,
      $dependencies,
      $version,
      true
    );

    wp_set_script_translations('wc-prontopaga-blocks', 'woocommerce-prontopaga');

    wp_register_style(
      'wc-prontopaga-blocks',
      PP_PLUGIN_URL . 'assets/css/checkout.css',
      array(),
      PP_VERSION
    );
    wp_enqueue_style('wc-prontopaga-blocks');

    return array('wc-prontopaga-blocks');
  }

  /**
   * Scripts for the block editor.
   *
   * @return string[]
   */
  public function get_payment_method_script_handles_for_admin()
  {
    return $this->get_payment_method_script_handles();
  }

  /**
   * Data exposed to the client via wc.wcSettings.getSetting('prontopaga_data').
   *
   * @return array
   */
  public function get_payment_method_data()
  {
    $title       = '';
    $description = '';
    $supports    = array('products');

    if ($this->gateway) {
      $title       = $this->gateway->get_title();
      $description = $this->gateway->get_description();
      $supports    = $this->gateway->supports;
    } else {
      $configs = WC_PRONTOPAGA_DB::prontoPagaGetConfig();
      if ($configs) {
        foreach ($configs as $c) {
          if ($c->name === 'TITLE') {
            $title = $c->value;
          }
          if ($c->name === 'DESCRIPTION') {
            $description = $c->value;
          }
        }
      }
    }

    return array(
      'title'          => $title,
      'description'    => $description,
      'icon'           => WC_PRONTOPAGA_DB::prontoPagaGetConfigValue('CHECKOUT_LOGO', ''),
      'supports'       => $supports,
      'paymentMethods' => $this->get_available_payment_methods(),
      'i18n'           => array(
        'selectMethod'   => __('Por favor seleccione el método de pago:', 'woocommerce-prontopaga'),
        'documentError'  => __('Ingrese su número de documento de identidad', 'woocommerce-prontopaga'),
        'methodError'    => __('Seleccione un método de pago', 'woocommerce-prontopaga'),
        'configError'    => __('El método de pago no se encuentra configurado correctamente', 'woocommerce-prontopaga'),
        'noMethods'      => __('No hay métodos de pago disponibles', 'woocommerce-prontopaga'),
        'placeOrderLabel'=> __('Pagar con ProntoPaga', 'woocommerce-prontopaga'),
      ),
    );
  }

  /**
   * Enabled payment methods with local logos for Blocks checkout.
   *
   * @return array<int, array{id:string,method:string,name:string,logo:string}>
   */
  private function get_available_payment_methods()
  {
    return WC_PRONTOPAGA_UTILS::getEnabledPaymentMethods();
  }
}
