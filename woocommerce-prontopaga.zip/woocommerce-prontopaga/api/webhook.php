<?php

include_once '../../../../wp-load.php';
include_once PP_DIR . '/includes/class-wc-prontopaga-api.php';
include_once PP_DIR . '/includes/class-wc-prontopaga-db.php';
include_once PP_DIR . '/includes/class-wc-prontopaga-utils.php';

$rawBody  = file_get_contents('php://input');
$dataJSON = json_decode($rawBody, true);

WC_PRONTOPAGA_UTILS::saveInfoLog('Webhook', $rawBody);

if (!is_array($dataJSON) || empty($dataJSON['order'])) {
    status_header(400);
    exit;
}

WC_PRONTOPAGA_UTILS::saveInfoLog('Webhook', isset($dataJSON['status']) ? $dataJSON['status'] : '');

$orderDB = WC_PRONTOPAGA_DB::prontoPagaGetOrderByOrderCode(sanitize_text_field($dataJSON['order']));
if ($orderDB == null) {
    status_header(404);
    exit;
}

$order = wc_get_order($orderDB->order_id);
if (!$order) {
    status_header(404);
    exit;
}

if ($order->get_status() != 'completed') {
    $configPP = WC_PRONTOPAGA_DB::prontoPagaGetConfig();
    $apiToken = $apiKey = $title = $description = $environment = $status = $paymentMethods = '';
    if ($configPP) {
        foreach ($configPP as $c) {
            if ($c->name == 'API_TOKEN') {
                $apiToken = $c->value;
            }
            if ($c->name == 'API_KEY') {
                $apiKey = $c->value;
            }
            if ($c->name == 'TITLE') {
                $title = $c->value;
            }
            if ($c->name == 'DESCRIPTION') {
                $description = $c->value;
            }
            if ($c->name == 'ENVIRONMENT') {
                $environment = $c->value;
            }
            if ($c->name == 'STATUS') {
                $status = $c->value;
            }
            if ($c->name == 'PAYMENT_METHODS') {
                $paymentMethods = $c->value;
            }
        }
    }

    $response = WC_PRONTOPAGA_API::getPaymentStatusPP($environment, $apiToken, $orderDB->uuid);
    if ($response == null) {
        return;
    }

    $statusCode = wp_remote_retrieve_response_code($response);
    if ($statusCode == 403) {
        WC_PRONTOPAGA_UTILS::saveErrorLog('webhook', wp_remote_retrieve_body($response));
        return;
    }

    $data = json_decode(wp_remote_retrieve_body($response));
    WC_PRONTOPAGA_UTILS::saveInfoLog('W-getPaymentStatusPP', wp_json_encode($data));

    if (isset($data->status) && $data->status == 'success') {
        if (function_exists('wc_reduce_stock_levels') && !$order->get_meta('_order_stock_reduced')) {
            wc_reduce_stock_levels($order->get_id());
        }

        if (function_exists('WC') && WC()->cart) {
            WC()->cart->empty_cart();
        }

        $nota = '<b>RECIBO</b><br/>
            <b>PRONTOPAGA</b><br/>
            <b>Estado:</b> ' . esc_html($data->status) . ' <br/>
            <b>Pedido:</b> ' . esc_html((string) $orderDB->order_id) . ' <br/>
            <b>Fecha y Hora:</b> ' . esc_html(gmdate('d-m-Y H:i')) . '<br/>
            <b>País:</b> ' . esc_html($data->country) . ' <br/>
            <b>Método de pago:</b> ' . esc_html($data->method) . ' <br/>
            <b>Tipo de método:</b> ' . esc_html($data->method_type) . '<br/>
            <b>Detalles de método:</b> ' . esc_html($data->method_detail) . ' <br/>
            <b>Referencia:</b> ' . esc_html($data->reference) . ' <br/>
            <b>Monto:</b> ' . esc_html($data->currency . ' ' . $data->amount) . ' <br/>';

        $order->add_order_note($nota, 1);
        $order->update_status($status);

        WC_PRONTOPAGA_DB::prontoPagaUpdateOrder($orderDB->id, $status);
    } elseif (isset($data->status) && $data->status == 'pending') {
        $order->update_status('on-hold');
        WC_PRONTOPAGA_DB::prontoPagaUpdateOrder($orderDB->id, 'on-hold');
    } else {
        $order->update_status('failed');
        WC_PRONTOPAGA_DB::prontoPagaUpdateOrder($orderDB->id, 'failed');
    }
}

status_header(200);
exit;
