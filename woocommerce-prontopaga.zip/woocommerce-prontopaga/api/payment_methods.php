<?php

include_once PP_DIR . '/includes/class-wc-prontopaga-api.php';
include_once PP_DIR . '/includes/class-wc-prontopaga-constants.php';

header("Content-Type: application/json");
$data = json_decode(file_get_contents("php://input"), true);
$token = $data["token"] ?? "";
$environment = $data["environment"] ?? "S";
if (empty($token)) {
  http_response_code(400);
  echo json_encode(["error" => "Token requerido"]);
  exit;
}
$ch = curl_init(WC_PRONTOPAGA_API::getEnvironmentPP($environment).WC_PRONTOPAGA_CONSTANTS::PP_PAYMENT_METHODS);
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => ["Authorization: Bearer " . $token]
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
if ($httpCode !== 200) {
  http_response_code(401);
  echo json_encode(["error" => "Token inválido"]);
  exit;
}
echo $response;
exit;
