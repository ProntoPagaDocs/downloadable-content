<?php
/**
 * Plugin Name: WooCommerce pagos con ProntoPaga
 * Plugin URI: https://docs.prontopaga.com/
 * Description: Módulo para pagos a través de ProntoPaga. Acepta pagos con tarjeta, billeteras electrónicas y Yape.
 * Version: 1.3.3
 * Requires at least: 6.9
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Author: ProntoPaga
 * Author URI: https://docs.prontopaga.com/
 * Text Domain: woocommerce-prontopaga
 * Domain Path: /langs
 * Copyright: © 2026 ProntoPaga.
 * WC requires at least: 8.0
 * WC tested up to: 11.0
 * Tested up to: 7.0
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */

if (!defined('ABSPATH')) {
  exit;
}

define('PP_DIR', plugin_dir_path(__FILE__));
define('PP_PLUGIN_FILE', __FILE__);
define('PP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('PP_VERSION', '1.3.3');

include_once dirname(__FILE__) . '/includes/class-wc-prontopaga-db.php';
include_once dirname(__FILE__) . '/includes/class-wc-prontopaga-api.php';
include_once dirname(__FILE__) . '/includes/class-wc-prontopaga-constants.php';
include_once dirname(__FILE__) . '/includes/class-wc-prontopaga-utils.php';

/**
 * Activate the plugin.
 */
function wc_prontopaga_activate()
{
  if (!class_exists('WooCommerce')) {
    deactivate_plugins(plugin_basename(__FILE__));
    wp_die(
      esc_html__('ProntoPaga requiere WooCommerce activo.', 'woocommerce-prontopaga'),
      esc_html__('Plugin desactivado', 'woocommerce-prontopaga'),
      array('back_link' => true)
    );
  }

  WC_PRONTOPAGA_UTILS::saveInfoLog('', 'Activando plugin');
  WC_PRONTOPAGA_DB::prontoPagaCreateTableConfig();
  WC_PRONTOPAGA_DB::prontoPagaInsertDataTableConfig();
  WC_PRONTOPAGA_DB::prontoPagaCreateTableOrder();
}
register_activation_hook(__FILE__, 'wc_prontopaga_activate');

/**
 * Declare compatibility with WooCommerce features (HPOS + Cart/Checkout Blocks).
 */
add_action('before_woocommerce_init', function () {
  if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
    \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
  }
});

/**
 * Register ProntoPaga with WooCommerce Blocks checkout.
 */
add_action(
  'woocommerce_blocks_payment_method_type_registration',
  function ($payment_method_registry) {
    if (!class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
      return;
    }
    require_once PP_DIR . 'includes/class-wc-prontopaga-blocks.php';
    $payment_method_registry->register(new WC_ProntoPaga_Blocks());
  }
);

/**
 * Add DNI/document field to classic checkout.
 */
add_filter('woocommerce_checkout_fields', function ($fields) {
  if (!isset($fields['billing']) || !is_array($fields['billing'])) {
    return $fields;
  }

  if (isset($fields['billing']['billing_prontopaga_dni'])) {
    return $fields;
  }

  $fields['billing']['billing_prontopaga_dni'] = array(
    'type'        => 'text',
    'label'       => __('Documento de identidad', 'woocommerce-prontopaga'),
    'placeholder' => __('Número de documento', 'woocommerce-prontopaga'),
    'required'    => true,
    'class'       => array('form-row-wide'),
    'priority'    => 25,
    'clear'       => true,
  );

  return $fields;
}, 20);

add_filter('woocommerce_billing_fields', function ($fields) {
  if (isset($fields['billing_prontopaga_dni'])) {
    return $fields;
  }

  $fields['billing_prontopaga_dni'] = array(
    'type'        => 'text',
    'label'       => __('Documento de identidad', 'woocommerce-prontopaga'),
    'placeholder' => __('Número de documento', 'woocommerce-prontopaga'),
    'required'    => true,
    'class'       => array('form-row-wide'),
    'priority'    => 25,
    'clear'       => true,
  );

  return $fields;
}, 20);

/**
 * Persist DNI on the order for classic checkout.
 */
add_action('woocommerce_checkout_create_order', function ($order, $data) {
  $dni = '';
  if (!empty($data['billing_prontopaga_dni'])) {
    $dni = sanitize_text_field($data['billing_prontopaga_dni']);
  } elseif (!empty($_POST['billing_prontopaga_dni'])) {
    $dni = sanitize_text_field(wp_unslash($_POST['billing_prontopaga_dni']));
  } elseif (!empty($_POST['prontoPaga_input_dni'])) {
    $dni = sanitize_text_field(wp_unslash($_POST['prontoPaga_input_dni']));
  }

  if ($dni !== '') {
    $order->update_meta_data('_billing_prontopaga_dni', $dni);
    $order->update_meta_data('billing_prontopaga_dni', $dni);
  }
}, 20, 2);

add_action('woocommerce_checkout_update_order_meta', function ($order_id) {
  $order = wc_get_order($order_id);
  if (!$order) {
    return;
  }
  $dni = WC_PRONTOPAGA_UTILS::getCustomerDocument($order);
  if ($dni === '') {
    return;
  }
  $order->update_meta_data('_billing_prontopaga_dni', $dni);
  $order->update_meta_data('billing_prontopaga_dni', $dni);
  $order->save();
}, 20);

/**
 * When Blocks saves additional fields, mirror DNI into a simple meta key.
 */
add_action('woocommerce_set_additional_field_value', function ($key, $value, $group, $wc_object) {
  if ($key !== 'prontopaga/dni' || !is_object($wc_object) || !method_exists($wc_object, 'update_meta_data')) {
    return;
  }
  $dni = sanitize_text_field((string) $value);
  if ($dni === '') {
    return;
  }
  $wc_object->update_meta_data('_billing_prontopaga_dni', $dni);
  $wc_object->update_meta_data('billing_prontopaga_dni', $dni);
}, 10, 4);

/**
 * Add document field to Blocks checkout.
 */
add_action('woocommerce_init', function () {
  if (!function_exists('woocommerce_register_additional_checkout_field')) {
    return;
  }

  woocommerce_register_additional_checkout_field(
    array(
      'id'       => 'prontopaga/dni',
      'label'    => __('Documento de identidad', 'woocommerce-prontopaga'),
      'location' => 'address',
      'type'     => 'text',
      'required' => true,
    )
  );
});
function pp_register_menu()
{
  $svg = file_get_contents(PP_DIR . '/assets/images/isotipo.svg');
  $b64 = base64_encode($svg);
  add_menu_page('ProntoPaga', 'ProntoPaga', 'manage_options', 'prontopaga', 'pp_create', 'data:image/svg+xml;base64,' . $b64);
}
add_action('admin_menu', 'pp_register_menu');

function ppGenerateToken($options)
{
  $headers = array('Authorization' => 'Basic ' . base64_encode($options['username'] . ':' . $options['password']));
  $baseUrl = WC_PRONTOPAGA_API::getEnvironmentPP($options['environment'] ?? 'S');
  $response = wp_remote_request(
    $baseUrl . 'api.security/v1/security',
    array('method' => 'GET', 'headers' => $headers)
  );
  if (is_wp_error($response)) {
    return null;
  }
  return $response;
}

function ppGenerateOrder($options, $token, $data)
{
  $headers = array('Authorization' => $token, 'Content-Type' => 'application/json');
  $baseUrl = WC_PRONTOPAGA_API::getEnvironmentPP($options['environment'] ?? 'S');
  $customer = [];
  if ($data['plCustomerFirstName'] != '') {
    $customer['firstName'] = $data['plCustomerFirstName'];
  }
  if ($data['plCustomerLastName'] != '') {
    $customer['lastName'] = $data['plCustomerLastName'];
  }
  if ($data['plCustomerEmail'] != '') {
    $customer['email'] = $data['plCustomerEmail'];
  }
  if ($data['plCustomerPhone'] != '') {
    $customer['phoneNumber'] = $data['plCustomerPhone'];
  }
  if ($data['plCustomerDocumentType'] != '') {
    $customer['documentType'] = $data['plCustomerDocumentType'];
  }
  if ($data['plCustomerDocumentNumber'] != '') {
    $customer['documentNumber'] = $data['plCustomerDocumentNumber'];
  }
  if (count($customer) == 0) {
    $customer = new stdClass;
  }
  $body = [
    'externalId' => $data['plExternalId'],
    'orderType' => 'SINGLEPAY',
    'description' => $data['plDescription'],
    'amount' => $data['plAmount'],
    'customer' => $customer,
  ];
  $response = wp_remote_post(
    $baseUrl . 'api.ordermgmt/api/v1/order/create/' . $options['merchant'],
    ['headers' => $headers, 'body' => wp_json_encode($body)]
  );
  if (is_wp_error($response)) {
    return null;
  }
  return $response;
}

function showMessagePP2($error, $message)
{
  echo "<div class='container mt-5'>";
  echo $error ? "<div class='pl-alert-error'>$message</div>" : "<div class='pl-alert-success'>$message</div>";
  echo "</div>";
}

function pp_create()
{
  $message = 'Introduce tu token para validar los métodos de pago';
  $methods = null;
  $methodsStatusCode = null;
  $savedNotice = '';

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_admin_referer('prontopaga_save_settings');

    if (isset($_POST['ppBtnOption']) && (string) $_POST['ppBtnOption'] === '0') {
      $methodsResponse = WC_PRONTOPAGA_API::getPaymentMethods($_POST['ppEnvironment'] ?? 'S', $_POST['ppApiToken'] ?? '');
      if ($methodsResponse != null) {
        $methodsStatusCode = wp_remote_retrieve_response_code($methodsResponse);
        if ($methodsStatusCode == 200) {
          WC_PRONTOPAGA_DB::prontoPagaUpdateConfig('API_TOKEN', sanitize_text_field(wp_unslash($_POST['ppApiToken'] ?? '')));
          WC_PRONTOPAGA_DB::prontoPagaUpdateConfig('ENVIRONMENT', sanitize_text_field(wp_unslash($_POST['ppEnvironment'] ?? 'S')));
        } elseif ($methodsStatusCode == 403) {
          $message = 'Tu IP no se encuentra activa';
        }
      }
    } else {
      WC_PRONTOPAGA_DB::prontoPagaUpdateConfig('API_TOKEN', sanitize_text_field(wp_unslash($_POST['ppApiToken'] ?? '')));
      WC_PRONTOPAGA_DB::prontoPagaUpdateConfig('API_KEY', sanitize_text_field(wp_unslash($_POST['ppApiKey'] ?? '')));
      WC_PRONTOPAGA_DB::prontoPagaUpdateConfig('TITLE', sanitize_text_field(wp_unslash($_POST['ppTitle'] ?? '')));
      WC_PRONTOPAGA_DB::prontoPagaUpdateConfig('DESCRIPTION', sanitize_textarea_field(wp_unslash($_POST['ppDescription'] ?? '')));
      WC_PRONTOPAGA_DB::prontoPagaUpdateConfig('ENVIRONMENT', sanitize_text_field(wp_unslash($_POST['ppEnvironment'] ?? 'S')));
      WC_PRONTOPAGA_DB::prontoPagaUpdateConfig('STATUS', sanitize_text_field(wp_unslash($_POST['ppStatus'] ?? 'processing')));
      WC_PRONTOPAGA_DB::prontoPagaUpdateConfig('CHECKOUT_LOGO', esc_url_raw(wp_unslash($_POST['ppCheckoutLogo'] ?? '')));

      $methodsToSave = WC_PRONTOPAGA_UTILS::buildPaymentMethodsFromPost($_POST['ppPaymentMethods'] ?? array());
      WC_PRONTOPAGA_DB::prontoPagaUpdateConfig('PAYMENT_METHODS', wp_json_encode($methodsToSave));
      $savedNotice = 'Configuración guardada correctamente.';
    }
  }

  $config = WC_PRONTOPAGA_DB::prontoPagaGetConfig();
  $apiToken = $apiKey = $title = $description = $environment = $status = $paymentMethods = $checkoutLogo = '';
  if ($config) {
    foreach ($config as $c) {
      if ($c->name == 'API_TOKEN') {
        $apiToken = $c->value;
      }
      if ($c->name == 'API_KEY') {
        $apiKey = $c->value;
      }
      if ($c->name == 'TITLE') {
        $title = $c->value;
      }
      if ($c->name == 'DESCRIPTION') {
        $description = $c->value;
      }
      if ($c->name == 'ENVIRONMENT') {
        $environment = $c->value;
      }
      if ($c->name == 'STATUS') {
        $status = $c->value;
      }
      if ($c->name == 'PAYMENT_METHODS') {
        $paymentMethods = $c->value;
      }
      if ($c->name == 'CHECKOUT_LOGO') {
        $checkoutLogo = $c->value;
      }
    }
  }

  $savedMethodsMap = WC_PRONTOPAGA_UTILS::normalizePaymentMethodsConfig($paymentMethods);

  if ($methods == null && $apiToken != '') {
    $methodsResponse = WC_PRONTOPAGA_API::getPaymentMethods($environment ?? 'S', $apiToken ?? '');
    if ($methodsResponse != null) {
      $methodsStatusCode = wp_remote_retrieve_response_code($methodsResponse);
      if ($methodsStatusCode == 403) {
        $message = 'Tu IP no se encuentra activa';
      } elseif ($methodsStatusCode == 200) {
        $methods = json_decode(wp_remote_retrieve_body($methodsResponse));
        $message = '';
      } else {
        $message = 'Token inválido';
      }
    }
  }

  wp_enqueue_media();

  // Ensure checkout logo config key exists without reactivating the plugin.
  if (WC_PRONTOPAGA_DB::prontoPagaGetConfigValue('CHECKOUT_LOGO', null) === null) {
    WC_PRONTOPAGA_DB::prontoPagaUpdateConfig('CHECKOUT_LOGO', '');
  }
  // Widen config value column for multi-method logos.
  WC_PRONTOPAGA_DB::prontoPagaCreateTableConfig();
?>
  <link rel="stylesheet" href="<?= esc_url(plugins_url('assets/css/index.css', __FILE__)); ?>">
  <link rel="stylesheet" href="<?= esc_url(plugins_url('assets/css/bootstrap-grid.min.css', __FILE__)); ?>">
  <script src="https://unpkg.com/lucide@latest"></script>
  <script src="<?= esc_url(plugins_url('assets/js/index.js', __FILE__)); ?>"></script>

  <div class="wrap">
    <?php if ($savedNotice !== '') : ?>
      <div class="notice notice-success is-dismissible"><p><?php echo esc_html($savedNotice); ?></p></div>
    <?php endif; ?>
    <form method="post">
      <?php wp_nonce_field('prontopaga_save_settings'); ?>
      <div class="row">
        <div class="col-12">
          <div class="card header-card">
            <div class="card-content">
              <div class="header-content">
                <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Logo-1-JHBXivbnK6xKTiNWzAbaBqpXV97RDp.png" alt="ProntoPaga Logo" class="logo">
              </div>
            </div>
          </div>

          <div class="card" id="tarjetaprincipal">
            <div class="card-content">

              <section class="pp-section2">
                <div class="pp-section2-header">

                  <svg class="pp-section2-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z" />
                  </svg>

                  <h2 class="pp-section2-title">Credenciales</h2>
                </div>
                <p class="pp-section2-description">
                  Ingresa las credenciales de autenticación que ProntoPaga te entrego o solicítalas desde
                  <a href="#">nuestro soporte</a>
                </p>
                <div id="validation-message" class="validation-message" style="display: none;"></div>

                <div class="pp-form-row">
                  <label class="pp-form-label">Ambiente</label>

                  <div class="pp-form-field radio-group">
                    <div class="radio-option">
                      <label class="radio-container">
                        <input type="radio" id="sandbox" name="ppEnvironment" value="S" class="radio-input" <?php if ($environment == 'S') { ?> checked <?php } ?>>
                        <div class="radio-outer"></div>
                        <div class="radio-inner"></div>
                      </label>
                      <label for="sandbox" class="radio-label">Sandbox</label>
                      <div class="tooltip-container">
                        <svg class="tooltip-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M12 16v-4m0-4h.01M22 12c0 5.523-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2s10 4.477 10 10Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <div class="tooltip-content">🧪 Ambiente de <strong>pruebas</strong> para realizar transacciones de prueba</div>
                      </div>
                    </div>
                    <div class="radio-option">
                      <label class="radio-container">
                        <input type="radio" id="production" name="ppEnvironment" value="P" class="radio-input" <?php if ($environment == 'P') { ?> checked <?php } ?>>
                        <div class="radio-outer"></div>
                        <div class="radio-inner"></div>
                      </label>
                      <label for="production" class="radio-label">Producción</label>
                      <div class="tooltip-container">
                        <svg class="tooltip-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M12 16v-4m0-4h.01M22 12c0 5.523-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2s10 4.477 10 10Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <div class="tooltip-content">🚀 Ambiente de <strong>producción</strong> para transacciones reales.</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="pp-form-row">
                  <label for="token" class="pp-form-label">Token de autenticación</label>
                  <div class="pp-form-field">
                    <div class="pp-input-wrapper">
                      <input type="password" id="token" class="token-input" name="ppApiToken" value="<?= $apiToken; ?>">
                      <button class="eye-button" id="toggle-token" type="button">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M2.42 12.713c-.203-.343-.305-.514-.305-.713 0-.2.102-.37.305-.713C3.759 8.3 7.215 4 12 4c4.786 0 8.24 4.3 9.58 7.287.203.343.305.514.305.713 0 .2-.102.37-.305.713C20.241 15.7 16.785 20 12 20c-4.786 0-8.24-4.3-9.58-7.287Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                          <path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>

                <div class="pp-form-row">
                  <label for="api" class="pp-form-label">Secret Key</label>
                  <div class="pp-form-field">
                    <div class="pp-input-wrapper">
                      <input type="password" id="api" class="api-input" name="ppApiKey" value="<?= $apiKey; ?>">
                      <button class="eye-button" id="toggle-api" type="button">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M2.42 12.713c-.203-.343-.305-.514-.305-.713 0-.2.102-.37.305-.713C3.759 8.3 7.215 4 12 4c4.786 0 8.24 4.3 9.58 7.287.203.343.305.514.305.713 0 .2-.102.37-.305.713C20.241 15.7 16.785 20 12 20c-4.786 0-8.24-4.3-9.58-7.287Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                          <path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>

                <div class="pp-form-row">
                  <div></div>
                  <div class="pp-form-field">
                    <button id="validate-button" class="button2" name="ppBtnOption" value="0">Validar credenciales</button>
                  </div>
                </div>
              </section>

              <div class="pp-separator"></div>

              <div class="section" style="margin-bottom: 20px; padding: 1.5rem;">
                <h2 class="section-title">
                  <svg class="pp-section2-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 0 0 2.25-2.25V6.75A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25v10.5A2.25 2.25 0 0 0 4.5 19.5Z" />
                  </svg>
                  Métodos de Pago
                </h2>
                <p class="pp-section2-description" style="margin-bottom: 1rem;">
                  Activa cada método, revisa su nombre y sube el logo manualmente. El checkout usará solo estos logos locales.
                </p>
                <div id="paymentMethods" class="payment-methods payment-methods-config">
                  <?php
                  if ($methods != null) {
                    foreach ($methods as $method) {
                      $method_id   = isset($method->id) ? (string) $method->id : '';
                      $method_slug = isset($method->method) ? (string) $method->method : '';
                      $method_name = isset($method->name) ? (string) $method->name : $method_slug;
                      $saved       = isset($savedMethodsMap[$method_id]) ? $savedMethodsMap[$method_id] : null;
                      $is_enabled  = $saved ? !empty($saved['enabled']) : false;
                      $logo_url    = $saved && !empty($saved['logo']) ? $saved['logo'] : '';
                      $field_base  = 'ppPaymentMethods[' . esc_attr($method_id) . ']';
                      ?>
                      <div class="payment-method payment-method-config<?php echo $is_enabled ? ' selected' : ''; ?>" data-id="<?php echo esc_attr($method_id); ?>">
                        <label class="payment-method-enable">
                          <input
                            type="checkbox"
                            class="ppCheckPayment"
                            name="<?php echo $field_base; ?>[enabled]"
                            value="1"
                            <?php checked($is_enabled); ?>
                          />
                          <span class="payment-method-name"><?php echo esc_html($method_name); ?></span>
                        </label>

                        <input type="hidden" name="<?php echo $field_base; ?>[id]" value="<?php echo esc_attr($method_id); ?>" />
                        <input type="hidden" name="<?php echo $field_base; ?>[method]" value="<?php echo esc_attr($method_slug); ?>" />
                        <input type="hidden" name="<?php echo $field_base; ?>[name]" value="<?php echo esc_attr($method_name); ?>" />

                        <div class="payment-method-logo-box">
                          <div class="payment-method-logo-preview">
                            <?php if ($logo_url !== '') : ?>
                              <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($method_name); ?>" class="pp-logo-preview-img" />
                            <?php else : ?>
                              <span class="pp-logo-placeholder">Sin logo</span>
                            <?php endif; ?>
                          </div>
                          <input type="hidden" class="pp-logo-url" name="<?php echo $field_base; ?>[logo]" value="<?php echo esc_url($logo_url); ?>" />
                          <div class="payment-method-logo-actions">
                            <button type="button" class="button2 pp-upload-logo-btn">Subir logo</button>
                            <button type="button" class="button2 button2-secondary pp-remove-logo-btn" <?php echo $logo_url === '' ? 'style="display:none;"' : ''; ?>>Quitar</button>
                          </div>
                        </div>
                      </div>
                      <?php
                    }
                  }
                  ?>
                </div>
                <?php
                if ($message != '') {
                  echo '<div class="token-validation-message" id="token-validation-message">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="alert-circle-icon">
                      <circle cx="12" cy="12" r="10"></circle>
                      <line x1="12" y1="8" x2="12" y2="12"></line>
                      <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    <p>' . esc_html($message) . '</p>
                  </div>';
                }
                ?>
              </div>

              <hr>

              <section class="pp-section2">
                <div class="pp-section2-header">

                  <svg class="pp-section2-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" />
                  </svg>

                  <h2 class="pp-section2-title">Apariencia</h2>
                </div>
                <p class="pp-section2-description">Configura la información y el logo que se mostrarán en el checkout.</p>

                <div class="pp-form-row">
                  <label for="titulo" class="pp-form-label">Título del método de pago</label>
                  <div class="pp-form-field">
                    <input type="text" id="title" placeholder="Paga con ProntoPaga" name="ppTitle" value="<?= esc_attr($title); ?>">
                  </div>
                </div>

                <div class="pp-form-row align-top">
                  <label for="descripcion" class="pp-form-label pt-2">Descripción</label>
                  <div class="pp-form-field">
                    <textarea id="descripcion" name="ppDescription" placeholder="Ingresa una descripción"><?= esc_textarea($description); ?></textarea>
                  </div>
                </div>

                <div class="pp-form-row align-top">
                  <label class="pp-form-label pt-2">Logo del checkout</label>
                  <div class="pp-form-field">
                    <p class="pp-section2-description" style="margin: 0 0 0.75rem;">
                      Este logo aparece junto a ProntoPaga en la lista de métodos de pago del checkout. Al seleccionarlo se muestran los métodos con sus logos.
                    </p>
                    <div class="pp-checkout-logo-uploader" id="ppCheckoutLogoUploader">
                      <div class="payment-method-logo-preview pp-checkout-logo-preview">
                        <?php if ($checkoutLogo !== '') : ?>
                          <img src="<?php echo esc_url($checkoutLogo); ?>" alt="Logo checkout" class="pp-logo-preview-img" />
                        <?php else : ?>
                          <span class="pp-logo-placeholder">Sin logo del checkout</span>
                        <?php endif; ?>
                      </div>
                      <input type="hidden" id="ppCheckoutLogo" class="pp-checkout-logo-url" name="ppCheckoutLogo" value="<?php echo esc_url($checkoutLogo); ?>" />
                      <div class="payment-method-logo-actions">
                        <button type="button" class="button2 pp-upload-checkout-logo-btn">Subir logo del checkout</button>
                        <button type="button" class="button2 button2-secondary pp-remove-checkout-logo-btn" <?php echo $checkoutLogo === '' ? 'style="display:none;"' : ''; ?>>Quitar</button>
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              <hr>

              <section class="pp-section2">
                <div class="pp-section2-header">
                  <svg class="pp-section2-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.64.87a6.74 6.74 0 0 1 1.108.634c.326.225.726.307 1.106.206l1.224-.329a1.107 1.107 0 0 1 1.214.502l1.296 2.245c.275.477.164 1.083-.26 1.424l-.98.788a1.125 1.125 0 0 0-.36 1.187 6.784 6.784 0 0 1 0 1.268 1.125 1.125 0 0 0 .36 1.187l.98.788c.424.341.535.947.26 1.424l-1.296 2.245a1.107 1.107 0 0 1-1.214.502l-1.224-.329a1.125 1.125 0 0 0-1.106.206 6.74 6.74 0 0 1-1.108.634c-.327.184-.577.496-.64.87l-.213 1.281c-.09.542-.56.94-1.11.94H10.704c-.55 0-1.02-.398-1.11-.94l-.213-1.281a1.125 1.125 0 0 0-.64-.87 6.74 6.74 0 0 1-1.108-.634 1.125 1.125 0 0 0-1.106-.206l-1.224.329a1.107 1.107 0 0 1-1.214-.502l-1.296-2.245a1.125 1.125 0 0 1 .26-1.424l.98-.788a1.125 1.125 0 0 0 .36-1.187 6.784 6.784 0 0 1 0-1.268 1.125 1.125 0 0 0-.36-1.187l-.98-.788a1.125 1.125 0 0 1-.26-1.424l1.296-2.245a1.107 1.107 0 0 1 1.214-.502l1.224.329c.38.101.78.019 1.106-.206a6.74 6.74 0 0 1 1.108-.634c.327-.184.577-.496.64-.87l.213-1.281Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    <path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                  </svg>
                  <h2 class="pp-section2-title">Ajustes adicionales</h2>
                </div>
                <p class="pp-section2-description">Configura el funcionamiento de tu integración y el estado final.</p>

                <div class="pp-form-row">
                  <label class="pp-form-label">Estado final de la transacción</label>
                  <div class="pp-form-field radio-group">
                    <div class="radio-option">
                      <label class="radio-container">
                        <input type="radio" id="procesado" name="ppStatus" value="processing" class="radio-input" <?php if ($status == 'processing') { ?> checked <?php } ?>>
                        <div class="radio-outer"></div>
                        <div class="radio-inner"></div>
                      </label>
                      <label for="procesado" class="radio-label">Procesando</label>
                      <div class="tooltip-container">
                        <svg class="tooltip-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M12 16v-4m0-4h.01M22 12c0 5.523-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2s10 4.477 10 10Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <div class="tooltip-content">Usa este estado si necesitas completar el proceso manualmente, por ejemplo si vas a facturar o a enviar el producto</div>
                      </div>
                    </div>
                    <div class="radio-option">
                      <label class="radio-container">
                        <input type="radio" id="completada" name="ppStatus" value="completed" class="radio-input" <?php if ($status == 'completed') { ?> checked <?php } ?>>
                        <div class="radio-outer"></div>
                        <div class="radio-inner"></div>
                      </label>
                      <label for="completada" class="radio-label">Completada</label>
                      <div class="tooltip-container">
                        <svg class="tooltip-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M12 16v-4m0-4h.01M22 12c0 5.523-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2s10 4.477 10 10Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <div class="tooltip-content">Esa este estado si con el pago el pedido ha sido completado y no debes hacer nada más, útil para productos digitales</div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
              <div class="pp-save-button">
                <button id="saveButton" class="pp-button">
                  <i data-lucide="save"></i>
                  Guardar Configuración
                </button>
              </div>





              <!-- <div class="">
                  <label for="token">Token de autenticación</label>
                  <div class="input-with-button">
                    <div class="input-with-icon-token">
                      <input type="password" id="token" name="ppApiToken" value="<?= $apiToken; ?>" required>
                      <i data-lucide="check-circle-2" class="input-icon" style="display: none;"></i>
                    </div>
                    <button id="validateButton" class="button" name="ppBtnOption" value="0">
                      <span>Validar</span>
                      <div class="loader" style="display: none;"></div>
                    </button>
                  </div>
                </div>
                <div class="input-group">
                  <label for="apiKey">API Key</label>
                  <input type="password" id="apiKey" name="ppApiKey" value="<?= $apiKey; ?>">
                </div> -->
              <!-- <div class="pp-separator"></div>
              <div class="section">
                <h2 class="section-title">
                  <i data-lucide="globe-2"></i>
                  Configuración General
                </h2>
                <div class="input-row">
                  <div class="input-group">
                    <label for="title">Título de la Integración</label>
                    <input type="text" id="title" name="ppTitle" value="<?= $title; ?>">
                  </div>
                  <div class="input-group">
                    <label>Ambiente</label>
                    <div class="switch-container">
                      <span class="switch-label">🧪 Sandbox</span>
                      <label class="modern-switch">
                        <input type="checkbox" id="environmentToggle" name="ppEnvironment" value="P" <?php if ($environment == 'P') { ?> checked <?php } ?>>
                        <span class="modern-slider"></span>
                      </label>
                      <span class="switch-label">🚀 Producción</span>
                    </div>
                  </div>
                </div>
                <div class="input-group">
                  <label for="description">Descripción</label>
                  <textarea id="description" name="ppDescription" placeholder="Describe tu integración..."><?= $description; ?></textarea>
                </div>
                <div class="config-row">
                  <div class="input-group">
                    <label for="imageUpload">Imagen de la Integración</label>
                    <div class="image-upload">
                      <input type="file" id="imageUpload" accept="image/*">
                      <img id="imagePreview" src="/placeholder.svg" alt="Preview" class="image-preview">
                    </div>
                  </div>
                  <div class="input-group">
                    <label>Estado Final de la Transacción</label>
                    <div class="switch-container">
                      <span class="switch-label">Procesando</span>
                      <label class="modern-switch">
                        <input type="checkbox" id="transactionStateToggle" name="ppStatus" value="completed" <?php if ($status == 'completed') { ?> checked <?php } ?>>
                        <span class="modern-slider"></span>
                      </label>
                      <span class="switch-label">Completado</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="pp-separator"></div>
              <div class="save-button">
                <button id="saveButton" class="button" type="submit" name="ppBtnOption" value="1">
                  <i data-lucide="save"></i>
                  Guardar Configuración
                </button>
              </div> -->
            </div>
          </div>
        </div>
    </form>
  </div>
  <script>
    function togglePasswordVisibility(inputId) {
      const input = document.getElementById(inputId);
      input.type = input.type === 'password' ? 'text' : 'password';
    }

    document.getElementById('toggle-token').addEventListener('click', () => togglePasswordVisibility('token'));
    document.getElementById('toggle-api').addEventListener('click', () => togglePasswordVisibility('api'));
  </script>
<?php
}



add_action('plugins_loaded', 'woocommerce_prontopaga_init', 0);
function woocommerce_prontopaga_init()
{
  if (!class_exists('WC_Payment_Gateway')) {
    return;
  }

  class WC_ProntoPaga extends WC_Payment_Gateway
  {
    /** @var string */
    public $apiToken = '';

    /** @var string */
    public $apiKey = '';

    /** @var string */
    public $environment = '';

    /** @var string */
    public $status = 'processing';

    /** @var string */
    public $paymentMethods = '';

    /** @var string */
    public $saveLog = 'no';

    /** @var string */
    public $checkoutLogo = '';

    public function __construct()
    {
      $this->id                 = WC_PRONTOPAGA_CONSTANTS::PP_PLUGIN_ID;
      $this->method_title       = WC_PRONTOPAGA_CONSTANTS::PP_PLUGIN_TITLE;
      $this->method_description = WC_PRONTOPAGA_CONSTANTS::PP_PLUGIN_DESCRIPTION;
      $this->has_fields         = true;
      $this->supports           = array('products');

      $this->form_fields = include 'includes/initFormFields.php';
      $this->init_settings();

      $configs = WC_PRONTOPAGA_DB::prontoPagaGetConfig();
      if ($configs) {
        foreach ($configs as $c) {
          if ($c->name == 'API_TOKEN') {
            $this->apiToken = $c->value;
          }
          if ($c->name == 'API_KEY') {
            $this->apiKey = $c->value;
          }
          if ($c->name == 'TITLE') {
            $this->title = $c->value;
          }
          if ($c->name == 'DESCRIPTION') {
            $this->description = $c->value;
          }
          if ($c->name == 'ENVIRONMENT') {
            $this->environment = $c->value;
          }
          if ($c->name == 'STATUS') {
            $this->status = $c->value;
          }
          if ($c->name == 'PAYMENT_METHODS') {
            $this->paymentMethods = $c->value;
          }
          if ($c->name == 'CHECKOUT_LOGO') {
            $this->checkoutLogo = $c->value;
          }
        }
      }
      $this->saveLog = $this->settings['saveLog'] ?? 'no';
      $this->icon    = !empty($this->checkoutLogo) ? $this->checkoutLogo : '';

      add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
      add_action('woocommerce_api_prontopaga', array($this, 'webhook'));
      add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
      add_action('wp_enqueue_scripts', array($this, 'enqueue_checkout_assets'));
    }

    /**
     * Frontend checkout assets.
     */
    public function enqueue_checkout_assets()
    {
      if (!is_checkout() && !is_wc_endpoint_url('order-pay')) {
        return;
      }
      wp_enqueue_style(
        'wc-prontopaga-checkout',
        PP_PLUGIN_URL . 'assets/css/checkout.css',
        array(),
        PP_VERSION
      );
    }

    /**
     * Gateway icon HTML for the payment method list.
     *
     * @return string
     */
    public function get_icon()
    {
      $icon_url = !empty($this->checkoutLogo) ? $this->checkoutLogo : $this->icon;
      if (empty($icon_url)) {
        return '';
      }

      $icon = '<img src="' . esc_url($icon_url) . '" class="pp-checkout-gateway-icon" alt="' . esc_attr($this->get_title()) . '" />';
      return apply_filters('woocommerce_gateway_icon', $icon, $this->id);
    }

    function showMessagePP($error, $message)
    {
      echo "<div class='wrap mt-1'>";
      echo $error ? "<div class='pp-alert-error'>$message</div>" : "<div class='pp-alert-success'>$message</div>";
      echo "</div>";
    }

    private function gPost($gurl, $jsonSolicitud, $bearer)
    {
      try {
        $ch = curl_init($gurl);
        if (!empty($jsonSolicitud)) {
          curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonSolicitud);
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json', 'Authorization: Bearer ' . $bearer));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
      } catch (Throwable $th) {
        // $this->createLog('error','gPost', "Line ".$th->getLine()." Error: ".$th->getMessage());
        WC_PRONTOPAGA_UTILS::saveErrorLog("gPost: ", $th->getMessage());
      }
    }

    public function validate_fields()
    {
      $payment = $this->get_posted_payment_field('prontopaga_payment');
      $dni     = WC_PRONTOPAGA_UTILS::getCustomerDocument();

      if ($payment === '') {
        wc_add_notice(__('Seleccione un método de pago', 'woocommerce-prontopaga'), 'error');
        return false;
      }
      if ($dni === '') {
        wc_add_notice(__('Ingrese su número de documento de identidad', 'woocommerce-prontopaga'), 'error');
        return false;
      }
      return true;
    }

    /**
     * Read a payment field from classic checkout POST or Blocks payment_data.
     *
     * @param string $key Field key.
     * @return string
     */
    private function get_posted_payment_field($key)
    {
      if (isset($_POST[$key])) {
        return sanitize_text_field(wp_unslash($_POST[$key]));
      }

      if (isset($_POST['payment_data']) && is_array($_POST['payment_data'])) {
        foreach ($_POST['payment_data'] as $entry) {
          if (!is_array($entry) || !isset($entry['key'], $entry['value'])) {
            continue;
          }
          if ($entry['key'] === $key) {
            return sanitize_text_field(wp_unslash($entry['value']));
          }
        }
      }

      return '';
    }

    public function payment_fields()
    {
      try {
        echo '<fieldset id="wc-' . esc_attr($this->id) . '-cc-form" class="wc-credit-card-form wc-payment-form pp-payment-fields" style="background:transparent;">';

        do_action('woocommerce_credit_card_form_start', $this->id);

        if ($this->environment == '' || $this->apiToken == '') {
          $this->showMessagePP(true, 'El método de pago no se encuentra configurado correctamente');
        }

        $enabledMethods = WC_PRONTOPAGA_UTILS::getEnabledPaymentMethods();

        if (empty($enabledMethods)) {
          $this->showMessagePP(true, 'No hay métodos de pago configurados. Actívalos y sube sus logos en ProntoPaga.');
        } else {
          if (!empty($this->description)) {
            echo '<p class="pp-gateway-description">' . wp_kses_post($this->description) . '</p>';
          }

          echo '<div class="checkout-container pp-methods-panel">
                  <h2 id="seleccionametodo">Por favor seleccione el método de pago:</h2>
                  <div id="payment-methods" class="payment-methods">';

          $is_first = true;
          foreach ($enabledMethods as $value) {
            $method   = esc_attr($value['method']);
            $name     = esc_attr($value['name']);
            $logo     = !empty($value['logo']) ? esc_url($value['logo']) : '';
            $has_logo = $logo !== '';
            $checked  = $is_first ? ' checked' : '';
            $selected = $is_first ? ' selected' : '';

            echo '<label class="payment-method-card' . ($has_logo ? ' has-logo' : '') . $selected . '" data-method="' . $method . '">
                              <input type="radio" id="payment_' . $method . '" name="prontopaga_payment" value="' . $method . '" title="' . $name . '"' . $checked . '>
                              <span class="payment-method-card-inner">';
            if ($has_logo) {
              echo '<img src="' . $logo . '" alt="' . $name . '" title="' . $name . '" class="pp-method-logo" loading="lazy">';
            }
            echo '<span class="payment-method-card-name">' . esc_html($value['name']) . '</span>
                              </span>
                          </label>';
            $is_first = false;
          }

          echo '</div>
              </div>';

          echo '<script>
                  (function() {
                    var root = document.querySelector(".pp-payment-fields");
                    if (!root) { return; }
                    root.addEventListener("change", function(e) {
                      if (!e.target || e.target.name !== "prontopaga_payment") { return; }
                      root.querySelectorAll(".payment-method-card").forEach(function(card) {
                        card.classList.toggle("selected", card.querySelector("input[type=radio]") === e.target);
                      });
                    });
                  })();
              </script>';
        }

        do_action('woocommerce_credit_card_form_end', $this->id);
        echo '</fieldset>';
      } catch (Throwable $th) {
        WC_PRONTOPAGA_UTILS::saveErrorLog('payment_fields', 'Line: ' . $th->getLine() . ' - Message: ' . $th->getMessage());
      }
    }

    public function process_payment($order_id)
    {
      try {
        $order = wc_get_order($order_id);
        if (!$order) {
          wc_add_notice(__('Pedido no encontrado.', 'woocommerce-prontopaga'), 'error');
          return;
        }

        $amount         = (int) number_format($order->get_total(), 0, ',', '');
        $paymentMethod  = $this->get_posted_payment_field('prontopaga_payment');
        $clientDocument = WC_PRONTOPAGA_UTILS::getCustomerDocument($order);

        if ($paymentMethod === '') {
          wc_add_notice(__('Seleccione un método de pago', 'woocommerce-prontopaga'), 'error');
          return;
        }

        if ($clientDocument === '') {
          WC_PRONTOPAGA_UTILS::saveErrorLog('process_payment', 'DNI vacío. POST keys: ' . wp_json_encode(array_keys($_POST)));
          wc_add_notice(__('Por favor ingrese su número de documento de identidad', 'woocommerce-prontopaga'), 'error');
          return;
        }

        // Keep a simple meta copy for later webhooks / thankyou.
        $order->update_meta_data('_billing_prontopaga_dni', $clientDocument);
        $order->update_meta_data('billing_prontopaga_dni', $clientDocument);
        $order->save();


        $codeOrder = $order_id . '-' . gmdate('YmdHis');
        $body      = WC_PRONTOPAGA_UTILS::getPaymentBodyPP($order, $this->apiKey, $amount, $paymentMethod, $codeOrder, plugins_url('', __FILE__), $clientDocument);
        $response  = WC_PRONTOPAGA_API::newPaymentPP($this->environment, $this->apiToken, $body);

        if ($response === null) {
          wc_add_notice(__('No se pudo conectar con ProntoPaga. Intente nuevamente.', 'woocommerce-prontopaga'), 'error');
          return;
        }

        $gResponse = json_decode(wp_remote_retrieve_body($response));
        WC_PRONTOPAGA_UTILS::saveInfoLog('process_payment', isset($gResponse->uid) ? $gResponse->uid : wp_remote_retrieve_body($response));

        if (isset($gResponse->error->orderValidate)) {
          WC_PRONTOPAGA_UTILS::saveInfoLog('process_payment', 'La orden ya existe, por favor intente nuevamente.');
          wc_add_notice(__('La orden ya existe, por favor intente nuevamente', 'woocommerce-prontopaga'), 'error');
          return;
        }

        if (isset($gResponse->uid)) {
          WC_PRONTOPAGA_UTILS::saveInfoLog('process_payment', 'Peticion de pago solicitada, UUID: ' . $gResponse->uid);

          $order->update_meta_data('_uid', $gResponse->uid);
          $order->save();

          WC_PRONTOPAGA_DB::prontoPagaInsertDataTableOrder($order_id, $codeOrder, $gResponse->uid, wp_json_encode($body), $order->get_status(), $paymentMethod);

          return array(
            'result'   => 'success',
            'redirect' => $gResponse->urlPay,
          );
        }

        WC_PRONTOPAGA_UTILS::saveInfoLog('process_payment', 'Error ProntoPaga: ' . wp_json_encode(isset($gResponse->error) ? $gResponse->error : $gResponse));
        wc_add_notice(
          sprintf(
            /* translators: %s: error payload from ProntoPaga */
            __('No se pudo procesar su solicitud, ProntoPaga dice: %s', 'woocommerce-prontopaga'),
            wp_json_encode(isset($gResponse->error) ? $gResponse->error : $gResponse)
          ),
          'error'
        );
        return;
      } catch (Throwable $th) {
        WC_PRONTOPAGA_UTILS::saveErrorLog('process_payment', 'Line: ' . $th->getLine() . ' - Message: ' . $th->getMessage());
      }
    }

    public function webhook()
    {
      // global $woocommerce;
      // $orderDB = WC_PRONTOPAGA_DB::prontoPagaGetOrderByOrderCode($_GET['code']);
      // if ($orderDB != null) {
      //   $response = WC_PRONTOPAGA_API::getPaymentStatusPP($this->environment, $this->apiToken, $orderDB->uuid);
      //   if ($response == null) return;
      //   $statusCode = wp_remote_retrieve_response_code($response);
      //   if ($statusCode == 403) {
      //     WC_PRONTOPAGA_UTILS::saveErrorLog("webhook", wp_remote_retrieve_body($response));
      //     return;
      //   }
      //   $data = json_decode(wp_remote_retrieve_body($response));
      //   $order = new  WC_Order($orderDB->order_id);
      //   if ($data->status == 'success' || $data->status == 'pending') {
      //     $order->reduce_order_stock();
      //     $woocommerce->cart->empty_cart();

      //     $nota = "<b>🧾 RECIBO 🧾</b><br/>
      //       <b>PRONTOPAGA</b><br/>
      //       <b>Estado:</b> $data->status <br/>
      //       <b>Pedido:</b> " . $orderDB->order_id . "<br/>
      //       <b>Fecha y Hora:</b> " . date('d-m-Y H:i') . "<br/>
      //       <b>País:</b> $data->country <br/>
      //       <b>Método de pago:</b> $data->method_type <br/>
      //       <b>Tipo de método:</b> $data->method <br/>
      //       <b>Detalles de método:</b> $data->method_detail <br/>
      //       <b>Referencia:</b> $data->reference <br/>
      //       <b>Monto:</b> $data->currency $data->amount <br/>";

      //     $order->add_order_note($nota, 1);
      //     $order->update_status($this->status);
      //   } else {
      //     $order->update_status('failed');
      //     $order->add_order_note('El estado del pedido cambió de Pendiente de pago a Cancelado.');
      //   }
      // }
    }

    function thankyou_page($order_id)
    {
      $order = wc_get_order($order_id);
      if (!$order || !is_a($order, 'WC_Order')) {
        return;
      }

      $uid = $order->get_meta('_uid');
      if (empty($uid)) {
        return;
      }

      $orderDB = WC_PRONTOPAGA_DB::prontoPagaGetOrderByUid($uid);
      if ($orderDB == null) {
        return;
      }

      $response = WC_PRONTOPAGA_API::getPaymentStatusPP($this->environment, $this->apiToken, $orderDB->uuid);
      if ($response == null) {
        return;
      }

      $statusCode = wp_remote_retrieve_response_code($response);
      if ($statusCode == 403) {
        WC_PRONTOPAGA_UTILS::saveErrorLog('webhook', wp_remote_retrieve_body($response));
        return;
      }

      if ($order->get_status() !== 'pending') {
        return;
      }

      $data = json_decode(wp_remote_retrieve_body($response));
      if (!$data) {
        return;
      }

      if ($data->status == 'success' || $data->status == 'pending') {
        if (function_exists('wc_reduce_stock_levels') && !$order->get_meta('_order_stock_reduced')) {
          wc_reduce_stock_levels($order->get_id());
        }

        if (function_exists('WC') && WC()->cart) {
          WC()->cart->empty_cart();
        }

        $nota = '<b>RECIBO</b><br/>
            <b>PRONTOPAGA</b><br/>
            <b>Estado:</b> ' . esc_html($data->status) . ' <br/>
            <b>Pedido:</b> ' . esc_html((string) $orderDB->order_id) . '<br/>
            <b>Fecha y Hora:</b> ' . esc_html(gmdate('d-m-Y H:i')) . '<br/>
            <b>País:</b> ' . esc_html($data->country) . ' <br/>
            <b>Método de pago:</b> ' . esc_html($data->method_type) . ' <br/>
            <b>Tipo de método:</b> ' . esc_html($data->method) . ' <br/>
            <b>Detalles de método:</b> ' . esc_html($data->method_detail) . ' <br/>
            <b>Referencia:</b> ' . esc_html($data->reference) . ' <br/>
            <b>Monto:</b> ' . esc_html($data->currency . ' ' . $data->amount) . ' <br/>';

        $order->add_order_note($nota, 1);
        $order->update_status($this->status);
      } else {
        $order->update_status('failed');
        $order->add_order_note(__('El estado del pedido cambió de Pendiente de pago a Cancelado.', 'woocommerce-prontopaga'));
      }
    }
  }

  add_filter('woocommerce_payment_gateways', 'woocommerce_add_prontopaga');
  function woocommerce_add_prontopaga($methods)
  {
    $methods[] = 'WC_ProntoPaga';
    return $methods;
  }
}




// add_action('wp_enqueue_scripts', 'prontopaga_enqueue');
// function prontopaga_enqueue()
// {
//   wp_enqueue_style('pp-styles', plugins_url('assets/css/index.css', __FILE__));
//   wp_enqueue_style('pp-grid', plugins_url('assets/css/bootstrap-grid.min.css', __FILE__));
//   wp_enqueue_script('pp-lucide', 'https://unpkg.com/lucide@0.475.0/dist/umd/lucide.min.js', array(), null, true);
//   wp_enqueue_script('pp-script', plugins_url('assets/js/index.js', __FILE__));
// }