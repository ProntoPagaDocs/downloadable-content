=== WooCommerce pagos con ProntoPaga ===
Contributors: prontopaga
Tags: woocommerce, payments, prontopaga, checkout, blocks
Requires at least: 6.9
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.3.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Módulo de pagos ProntoPaga para WooCommerce (tarjeta, billeteras y Yape).

== Description ==

Acepta pagos con ProntoPaga en tu tienda WooCommerce.

Compatible con:
* High-Performance Order Storage (HPOS)
* Checkout clásico (shortcode)
* Checkout por bloques (Cart & Checkout Blocks)
* Logos de métodos de pago subidos manualmente

== Installation ==

1. Sube la carpeta del plugin a `/wp-content/plugins/`.
2. Activa el plugin desde el panel de WordPress.
3. Configura las credenciales en el menú ProntoPaga.
4. Activa el método de pago en WooCommerce → Ajustes → Pagos.

== Changelog ==

= 1.3.0 =
* Métodos de pago en configuración muestran el nombre claramente.
* Subida manual de logos por método (medios de WordPress).
* El checkout usa logos locales (ya no los descarga de la web).

= 1.2.0 =
* Soporte para checkout por bloques (WooCommerce Blocks).
* UI de métodos de pago y DNI en el checkout por bloques.
* Declaración de compatibilidad cart_checkout_blocks.

= 1.1.0 =
* Compatible con WordPress 7.0 y WooCommerce 11.0.
* Soporte HPOS con meta de pedidos vía CRUD de WooCommerce.
* Reemplazo de APIs deprecadas (`reduce_order_stock`, `global $woocommerce`).
* Headers de compatibilidad actualizados (Requires / Tested up to / WC tested up to).
* Declaración de propiedades del gateway para PHP 8.2+.

= 1.0.2 =
* Versión previa.
