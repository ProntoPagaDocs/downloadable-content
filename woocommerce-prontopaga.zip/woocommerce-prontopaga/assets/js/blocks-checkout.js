(function () {
	'use strict';

	if (
		typeof window.wc === 'undefined' ||
		typeof window.wc.wcBlocksRegistry === 'undefined' ||
		typeof window.wc.wcSettings === 'undefined' ||
		typeof window.wp === 'undefined' ||
		typeof window.wp.element === 'undefined'
	) {
		return;
	}

	var registerPaymentMethod = window.wc.wcBlocksRegistry.registerPaymentMethod;
	var getSetting = window.wc.wcSettings.getSetting;
	var el = window.wp.element.createElement;
	var useState = window.wp.element.useState;
	var useEffect = window.wp.element.useEffect;
	var decodeEntities =
		window.wp.htmlEntities && window.wp.htmlEntities.decodeEntities
			? window.wp.htmlEntities.decodeEntities
			: function (value) {
					return value;
			  };

	var settings = getSetting('prontopaga_data', {});
	var i18n = settings.i18n || {};
	var paymentMethods = Array.isArray(settings.paymentMethods)
		? settings.paymentMethods
		: [];
	var labelText = decodeEntities(settings.title || 'ProntoPaga');

	function readInputValue(selectors) {
		for (var i = 0; i < selectors.length; i++) {
			var node = document.querySelector(selectors[i]);
			if (node && typeof node.value === 'string' && node.value.trim() !== '') {
				return node.value.trim();
			}
		}
		return '';
	}

	function getDocumentFromCheckout() {
		var fromDom = readInputValue([
			'#billing_prontopaga_dni',
			'[name="billing_prontopaga_dni"]',
			'#billing-prontopaga-dni',
			'[id*="prontopaga-dni"]',
			'[id*="prontopaga/dni"]',
			'[name*="prontopaga/dni"]',
			'[name*="prontopaga-dni"]',
			'input[id*="billing-prontopaga"]',
			'#billing_dni',
			'[name="billing_dni"]',
			'#billing_document',
			'[name="billing_document"]',
		]);
		if (fromDom) {
			return fromDom;
		}

		try {
			if (window.wp && wp.data && typeof wp.data.select === 'function') {
				var checkoutStore = wp.data.select('wc/store/checkout');
				if (checkoutStore) {
					if (typeof checkoutStore.getAdditionalFields === 'function') {
						var additional = checkoutStore.getAdditionalFields() || {};
						var groups = ['billing', 'shipping', 'other', 'contact', 'address', 'order'];
						for (var g = 0; g < groups.length; g++) {
							var groupData = additional[groups[g]] || additional;
							if (groupData && groupData['prontopaga/dni']) {
								return String(groupData['prontopaga/dni']).trim();
							}
						}
						if (additional['prontopaga/dni']) {
							return String(additional['prontopaga/dni']).trim();
						}
					}

					if (typeof checkoutStore.getCustomerData === 'function') {
						var customer = checkoutStore.getCustomerData() || {};
						var billingAddress = customer.billingAddress || customer.billing_address || {};
						if (billingAddress['prontopaga/dni']) {
							return String(billingAddress['prontopaga/dni']).trim();
						}
						if (billingAddress.prontopaga_dni) {
							return String(billingAddress.prontopaga_dni).trim();
						}
					}
				}

				var cartStore = wp.data.select('wc/store/cart');
				if (cartStore && typeof cartStore.getCustomerData === 'function') {
					var cartCustomer = cartStore.getCustomerData() || {};
					var billing = cartCustomer.billingAddress || {};
					if (billing['prontopaga/dni']) {
						return String(billing['prontopaga/dni']).trim();
					}
					if (billing.prontopaga_dni) {
						return String(billing.prontopaga_dni).trim();
					}
				}
			}
		} catch (e) {
			// Ignore store read errors.
		}

		return '';
	}

	var Label = function () {
		var children = [];
		if (settings.icon) {
			children.push(
				el('img', {
					src: settings.icon,
					alt: labelText,
					className: 'pp-checkout-gateway-icon',
				})
			);
		}
		children.push(
			el('span', { className: 'wc-prontopaga-blocks-label-text' }, labelText)
		);
		return el('span', { className: 'wc-prontopaga-blocks-label' }, children);
	};

	var Content = function (props) {
		var eventRegistration = props.eventRegistration || {};
		var emitResponse = props.emitResponse || {};
		var onPaymentSetup = eventRegistration.onPaymentSetup;
		var responseTypes = emitResponse.responseTypes || {};

		var selectedMethodState = useState(
			paymentMethods.length ? paymentMethods[0].method : ''
		);
		var selectedMethod = selectedMethodState[0];
		var setSelectedMethod = selectedMethodState[1];

		useEffect(
			function () {
				if (!onPaymentSetup) {
					return undefined;
				}

				return onPaymentSetup(function () {
					var method = selectedMethod || '';
					var documentId = getDocumentFromCheckout();

					if (!paymentMethods.length) {
						return {
							type: responseTypes.ERROR,
							message: i18n.configError || i18n.noMethods || 'Error',
							messageContext: emitResponse.noticeContexts
								? emitResponse.noticeContexts.PAYMENTS
								: undefined,
						};
					}

					if (!method) {
						return {
							type: responseTypes.ERROR,
							message: i18n.methodError || 'Seleccione un método de pago',
							messageContext: emitResponse.noticeContexts
								? emitResponse.noticeContexts.PAYMENTS
								: undefined,
						};
					}

					if (!documentId) {
						return {
							type: responseTypes.ERROR,
							message:
								i18n.documentError ||
								'Ingrese su número de documento de identidad',
							messageContext: emitResponse.noticeContexts
								? emitResponse.noticeContexts.PAYMENTS
								: undefined,
						};
					}

					return {
						type: responseTypes.SUCCESS,
						meta: {
							paymentMethodData: {
								prontopaga_payment: method,
								prontoPaga_input_dni: documentId,
								billing_prontopaga_dni: documentId,
								'prontopaga/dni': documentId,
								clientDocument: documentId,
							},
						},
					};
				});
			},
			[
				onPaymentSetup,
				selectedMethod,
				responseTypes.ERROR,
				responseTypes.SUCCESS,
				emitResponse.noticeContexts,
			]
		);

		if (!paymentMethods.length) {
			return el(
				'div',
				{ className: 'pp-alert-error' },
				i18n.noMethods || i18n.configError || 'No hay métodos de pago disponibles'
			);
		}

		return el(
			'div',
			{ className: 'wc-prontopaga-blocks-content' },
			settings.description
				? el('p', null, decodeEntities(settings.description))
				: null,
			el(
				'div',
				{ className: 'checkout-container' },
				el(
					'h2',
					{ id: 'seleccionametodo' },
					i18n.selectMethod || 'Por favor seleccione el método de pago:'
				),
				el(
					'div',
					{ id: 'payment-methods', className: 'payment-methods' },
					paymentMethods.map(function (method) {
						var isSelected = selectedMethod === method.method;
						return el(
							'button',
							{
								type: 'button',
								key: method.method,
								className:
									'payment-method-card' +
									(isSelected ? ' selected' : ''),
								onClick: function (event) {
									event.preventDefault();
									event.stopPropagation();
									setSelectedMethod(method.method);
								},
							},
							method.logo
								? el('img', {
										src: method.logo,
										alt: method.name || method.method,
										title: method.name || method.method,
										className: 'pp-method-logo',
								  })
								: null,
							el(
								'span',
								{ className: 'payment-method-card-name' },
								method.name || method.method
							)
						);
					})
				)
			)
		);
	};

	var Edit = function () {
		return el(
			'div',
			{ className: 'wc-prontopaga-blocks-edit' },
			el('p', null, decodeEntities(settings.description || labelText)),
			el(
				'p',
				null,
				i18n.selectMethod || 'Por favor seleccione el método de pago:'
			)
		);
	};

	registerPaymentMethod({
		name: 'prontopaga',
		paymentMethodId: 'prontopaga',
		label: el(Label, null),
		content: el(Content, null),
		edit: el(Edit, null),
		canMakePayment: function () {
			return true;
		},
		ariaLabel: labelText,
		placeOrderButtonLabel:
			i18n.placeOrderLabel || 'Pagar con ProntoPaga',
		supports: {
			features: settings.supports || ['products'],
		},
	});
})();
