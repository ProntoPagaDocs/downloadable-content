lucide.createIcons();

const saveButton = document.getElementById('saveButton');
const successMessage = document.getElementById('successMessage');
let mediaFrame = null;

function saveConfiguration() {
  if (!successMessage) {
    return;
  }
  successMessage.classList.add('show');
  setTimeout(() => successMessage.classList.remove('show'), 3000);
}

if (saveButton) {
  saveButton.addEventListener('click', saveConfiguration);
}

function setLogoPreview(card, url) {
  const preview = card.querySelector('.payment-method-logo-preview');
  const hidden = card.querySelector('.pp-logo-url');
  const removeBtn = card.querySelector('.pp-remove-logo-btn');
  if (!preview || !hidden) {
    return;
  }

  hidden.value = url || '';

  if (url) {
    preview.innerHTML =
      '<img src="' +
      url.replace(/"/g, '&quot;') +
      '" alt="Logo" class="pp-logo-preview-img" />';
    if (removeBtn) {
      removeBtn.style.display = '';
    }
  } else {
    preview.innerHTML = '<span class="pp-logo-placeholder">Sin logo</span>';
    if (removeBtn) {
      removeBtn.style.display = 'none';
    }
  }
}

function openMediaUploader(card) {
  if (typeof wp === 'undefined' || !wp.media) {
    window.alert('El cargador de medios de WordPress no está disponible.');
    return;
  }

  if (mediaFrame) {
    mediaFrame.off('select');
  }

  mediaFrame = wp.media({
    title: 'Seleccionar logo del método de pago',
    button: { text: 'Usar este logo' },
    multiple: false,
    library: { type: 'image' },
  });

  mediaFrame.on('select', function () {
    const attachment = mediaFrame.state().get('selection').first().toJSON();
    setLogoPreview(card, attachment.url || '');
  });

  mediaFrame.open();
}

function setCheckoutLogoPreview(url) {
  const uploader = document.getElementById('ppCheckoutLogoUploader');
  if (!uploader) {
    return;
  }
  const preview = uploader.querySelector('.pp-checkout-logo-preview');
  const hidden = uploader.querySelector('.pp-checkout-logo-url');
  const removeBtn = uploader.querySelector('.pp-remove-checkout-logo-btn');
  if (!preview || !hidden) {
    return;
  }

  hidden.value = url || '';

  if (url) {
    preview.innerHTML =
      '<img src="' +
      url.replace(/"/g, '&quot;') +
      '" alt="Logo checkout" class="pp-logo-preview-img" />';
    if (removeBtn) {
      removeBtn.style.display = '';
    }
  } else {
    preview.innerHTML =
      '<span class="pp-logo-placeholder">Sin logo del checkout</span>';
    if (removeBtn) {
      removeBtn.style.display = 'none';
    }
  }
}

function openCheckoutLogoUploader() {
  if (typeof wp === 'undefined' || !wp.media) {
    window.alert('El cargador de medios de WordPress no está disponible.');
    return;
  }

  if (mediaFrame) {
    mediaFrame.off('select');
  }

  mediaFrame = wp.media({
    title: 'Seleccionar logo del checkout',
    button: { text: 'Usar este logo' },
    multiple: false,
    library: { type: 'image' },
  });

  mediaFrame.on('select', function () {
    const attachment = mediaFrame.state().get('selection').first().toJSON();
    setCheckoutLogoPreview(attachment.url || '');
  });

  mediaFrame.open();
}

document.addEventListener('click', function (event) {
  const uploadCheckoutBtn = event.target.closest('.pp-upload-checkout-logo-btn');
  if (uploadCheckoutBtn) {
    event.preventDefault();
    event.stopPropagation();
    openCheckoutLogoUploader();
    return;
  }

  const removeCheckoutBtn = event.target.closest('.pp-remove-checkout-logo-btn');
  if (removeCheckoutBtn) {
    event.preventDefault();
    event.stopPropagation();
    setCheckoutLogoPreview('');
    return;
  }

  const uploadBtn = event.target.closest('.pp-upload-logo-btn');
  if (uploadBtn) {
    event.preventDefault();
    event.stopPropagation();
    const card = uploadBtn.closest('.payment-method-config');
    if (card) {
      openMediaUploader(card);
    }
    return;
  }

  const removeBtn = event.target.closest('.pp-remove-logo-btn');
  if (removeBtn) {
    event.preventDefault();
    event.stopPropagation();
    const card = removeBtn.closest('.payment-method-config');
    if (card) {
      setLogoPreview(card, '');
    }
    return;
  }

  // Toggle enable checkbox when clicking the card (except inputs/buttons).
  const card = event.target.closest('.payment-method-config');
  if (
    card &&
    !event.target.closest('input, button, label.payment-method-enable, a')
  ) {
    const checkbox = card.querySelector('.ppCheckPayment');
    if (checkbox) {
      checkbox.checked = !checkbox.checked;
      card.classList.toggle('selected', checkbox.checked);
    }
  }
});

document.querySelectorAll('.payment-method-config .ppCheckPayment').forEach((checkbox) => {
  checkbox.addEventListener('change', function () {
    const card = this.closest('.payment-method-config');
    if (card) {
      card.classList.toggle('selected', this.checked);
    }
  });
});
